﻿using XplorPOCWebCoreApp.InterfaceServices;
using XplorPOCWebCoreApp.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace XplorPOCWebCoreApp.Services
{
    public class CustomerService:ICustomer

    {
        private readonly HttpClient _httpClient;
        public CustomerService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _httpClient.BaseAddress = new Uri("https://getinvoices.azurewebsites.net/api/");
        }

        public async Task<List<CustomerModel>> GetCustomers()
        {
            var response = await _httpClient.GetAsync("Customers");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var customers = JsonConvert.DeserializeObject<List<CustomerModel>>(content);
                return customers;
            }
            else
            {
                return null;
            }

        }

        public async Task<CustomerModel> GetCustomerById(string id)
        {
            var response = await _httpClient.GetAsync($"Customer/{id}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<CustomerModel>(content);
            }
            else
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<CustomerModel>(content);
            }

        }

        public async Task<CustomerModel> CreateCustomer(CustomerModel customer)
        {
            var json = JsonConvert.SerializeObject(customer);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync("Customer", httpContent);
            if (response.IsSuccessStatusCode) {
                var createdJson = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<CustomerModel>(createdJson);
            }
            else
            {
                return null;
            }
        }

        public async Task<CustomerModel> UpdateCustomer(string id, CustomerModel customer)
        {
            var json = JsonConvert.SerializeObject(customer);
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync($"Customer/{id}", httpContent);
            
            if (response.IsSuccessStatusCode)
            {
                var updatedJson = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<CustomerModel>(updatedJson);
            }
            else
            {
                return null;
            }
        }

        public async Task<bool> DeleteCustomer(string id)
        {
            var response = await _httpClient.DeleteAsync($"Customer/{id}");
            if (response.IsSuccessStatusCode)
            {
                return response.IsSuccessStatusCode;
            }
            else
            {
                return false;
            }
            
        }
    }
}
