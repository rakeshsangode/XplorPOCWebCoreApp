﻿using XplorPOCWebCoreApp.InterfaceServices;
using XplorPOCWebCoreApp.Models;
using XplorPOCWebCoreApp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace XplorPOCWebCoreApp.Controllers
{
    public class CustomerController : Controller
    {
        
        private readonly ICustomer _customerService;
        public CustomerController(ICustomer customerService)
        {
            _customerService = customerService;
        }
        public async Task<IActionResult> Index()
        {
            var customers = await _customerService.GetCustomers();
            return View(customers);
        }

        [HttpPost]
        public async Task<IActionResult> Add(CustomerModel customer)
        {
            if (ModelState.IsValid)
            {
                ViewBag.opFlag = "INSERT";
                var createdCustomer = await _customerService.CreateCustomer(customer);
                var customers = await _customerService.GetCustomers();
     
                return View("Index", customers);
            }
             return View(customer);
        }

        public async Task<IActionResult> AddEdit(string id)
        {
            if (id != null)
            {
                ViewBag.action = "Edit";
                var customer = await _customerService.GetCustomerById(id);
                return View("AddEdit", customer);
            }
            else
            {
                ViewBag.action = "Add";
                var customers = await _customerService.GetCustomers();

                var _maxIid = customers.Max(c => c.id)+1;
  
                return View("AddEdit",new CustomerModel(){  id= _maxIid });
            }
        }


        [HttpPost]
        public async Task<IActionResult> Edit(string id, CustomerModel customer)
        {

            if (ModelState.IsValid)
            {
                ViewBag.opFlag = "UPDATE";
                var updatedCustomer =  _customerService.UpdateCustomer(id, customer).Result;
                var customers = await _customerService.GetCustomers();
                
                return View("Index", customers);


            }
            return View(customer);
        }

        public async Task<IActionResult> Delete(string id)
        {
            ViewBag.opFlag = "DELETE";
            var customer = await _customerService.DeleteCustomer(id);
            var customers = await _customerService.GetCustomers();
           
            return View("Index", customers);
        }
    }
}
